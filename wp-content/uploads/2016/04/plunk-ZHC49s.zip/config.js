// System.config({
//   //use typescript for compilation
//   transpiler: 'typescript',
//   //typescript compiler options
//   typescriptOptions: {
//     emitDecoratorMetadata: true
//   },
//   //map tells the System loader where to look for things
//   map: {
//     app: './src',
//     'angular2': 'https://npmcdn.com/angular2',
//     'rxjs': 'https://npmcdn.com/rxjs@5.0.0-beta.4'
//   },
//   //packages defines our app package
//   packages: {
//     app: {
//       main: './main.ts',
//       defaultExtension: 'ts'
//     },
// });
