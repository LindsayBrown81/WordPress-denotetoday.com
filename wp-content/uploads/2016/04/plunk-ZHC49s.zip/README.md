### Plunker - Typescript - Beta 0

A plunker demonstrating development progress on Lynzphotos, an event photography website built using Angular2