import { Component, OnInit } from "angular2/core";
import { Router } from "angular2/router";

//Import the Image interface
import {Image} from "./image.interface";

//Component Decorator
@Component({
    selector: "css-carousel",
    template: `
 <div class="carousel">

  <ul class="slides">

    <li *ngFor="#image of images">
      <h2>{{image.title}}</h2>
      <img src="{{image.url}}" alt="can't find picture">
    </li>

  </ul>

</div>
  `,
    styles: [`
.carousel{
    overflow:hidden;
    width:100%;
}
.slides{
    list-style:none;
    position:relative;
    width:500%; /* Number of panes * 100% */
    overflow:hidden; /* Clear floats */
        /* Slide effect Animations */
    -moz-animation:carousel 30s infinite;
    -webkit-animation:carousel 30s infinite;
    animation:carousel 30s infinite;
    /* correct ng-scope misalignment */
    padding: 0;
    margin: 0;
}
.slides > li{
    position:relative;
    float:left;
    width: 20%; /* 100 / number of panes */
    padding: 0%;
}
.carousel img{
    display:block;
    width:100%;
    max-width:100%;
}
.carousel h2{
    margin-bottom: 0;
    font-size:1em;
    padding:0.25em 0.5em 0.25em 0.5em;
    position:absolute;
    right:0px;
    bottom:0px;
    left:0px;
    text-align:center;
    color:#fff;
    background-color:rgba(0,0,0,0.25);
}

@keyframes carousel{
    0%    { left:0; }
    11%   { left:0; }
    12.5% { left:-100%; }
    23.5% { left:-100%; }
    25%   { left:-200%; }
    36%   { left:-200%; }
    37.5% { left:-300%; }
    48.5% { left:-300%; }
    50%   { left:-400%; }
    61%   { left:-400%; }
    62.5% { left:-300%; }
    73.5% { left:-300%; }
    75%   { left:-200%; }
    86%   { left:-200%; }
    87.5% { left:-100%; }
    98.5% { left:-100%; }
    100%  { left:0; }
}
  `],//@keyframes powers the slideshow. All we do is animate .panels from right to left then back again on its infinite loop.
}) 

//Carousel Component itself
export class CSSCarouselComponent {
    //images data to be bound to the template
    public images = IMAGES;
}

//IMAGES array implementing Image interface
var IMAGES: Image[] = [
    { "title": "Sen. Cory Booker [D-NJ] with group post talk", "url": "https://lynzphotos.smugmug.com/Other/BookerSpeakerEvent03-30-2012/n-qjd5V/i-38tCp5H/1/2772x1848/i-38tCp5H-2772x1848.jpg" },
    { "title": "Sen. Chris Coons [D-DE] with his wife Annie backstage", "url": "https://lynzphotos.smugmug.com/Other/BookerSpeakerEvent03-30-2012/i-P3BXXcR/1/X3/051bw-X3.jpg" },
    { "title": "Sen. Cory Booker [D-NJ] speaks with a supporter", "url": "https://lynzphotos.smugmug.com/Other/BookerSpeakerEvent03-30-2012/i-J6wRhFx/0/2880x1920/020-2880x1920.jpg" },
    { "title": "Sen. Booker's staffer shares cheer", "url": "https://lynzphotos.smugmug.com/Other/BookerSpeakerEvent03-30-2012/i-nq7jCLK/1/X3/029-X3.jpg" },
    { "title": "Sen. Coons, Sen. Booker, and Bianca Levin pre event", "url": "https://lynzphotos.smugmug.com/Other/BookerSpeakerEvent03-30-2012/i-WVsK7zP/1/O/033bw.jpg" },
    // { "title": "TurMaidGrmnRed", "url": "images/TurMaidGrmnRed.jpg" },
    // { "title": "TurRngbrFlwgrls", "url": "images/TurRngbrFlwgrls.jpg" },
    // { "title": "TurGuest", "url": "images/TurGuest.jpg" },
    // { "title": "BrooksGuest", "url": "images/BrooksGuest.jpg" },
    // { "title": "AikStpnMaids", "url": "images/AikStpnMaids.jpg" },  
];





