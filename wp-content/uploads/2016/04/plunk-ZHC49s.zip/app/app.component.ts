import { Component, OnInit } from 'angular2/core';
import { RouteConfig, ROUTER_DIRECTIVES, ROUTER_PROVIDERS } from 'angular2/router';

import { Router } from 'angular2/router';
import {CSSCarouselComponent} from './carousel.component';
import {PublicEventsComponent} from './public-events.component';
// import {HomeComponent} from "./pages/home/home.component";

@Component({ //a component controls a portion of the screen — a view — through its associated template.
	selector: 'my-app', //The CSS selector
	template: `
	<h1>{{title}}</h1>
  <div class="grid">
  <nav>
    <a>Home</a>
    <a [routerLink]="['PublicEvents']" class="router-link-active">Public Events</a>
    <a>Private Events</a>
    <a>About</a>
    <a>Pricing</a>
  </nav>
  </div>
  <router-outlet></router-outlet>
	`,
	directives: [ROUTER_DIRECTIVES, CSSCarouselComponent],//tell angular we are using the css-carousel tag in this component
  providers: [
    ROUTER_PROVIDERS
  ]
})
@RouteConfig([
//   {
// 		path: "/home",/*the router matches this route's path to the URL in the browser address bar */
// 		name: "Home",/*the official name of the route; it must begin with a capital letter to avoid confusion with the path*/
// 		component: HomeComponent/*the component that the router should create when navigating to this route*/
// 	},
	{
		path: '/public-events',/*the router matches this route's path to the URL in the browser address bar */
		name: 'PublicEvents',/*the official name of the route; it must begin with a capital letter to avoid confusion with the path*/
		component: PublicEventsComponent,/*the component that the router should create when navigating to this route*/
	  useAsDefault: true
	},
])
export class AppComponent { 
	constructor() {
		console.log('Application is bootstrapped!');
	}
}