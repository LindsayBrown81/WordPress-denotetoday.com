export interface Image {
	title: string;
	url: string;
}

