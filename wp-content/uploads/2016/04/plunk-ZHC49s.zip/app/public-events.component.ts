import { Component, OnInit } from 'angular2/core';
import { Router } from 'angular2/router';
import {CSSCarouselComponent} from "./carousel.component";

@Component({
    selector: "page-public-events",
    template: `
    <br>
    {{message}}<br>
    {{images}}<br>
    <div class="wrapper">
        <css-carousel>
            <div class="carousel">
                <ul class="slides">
                    <li *ngFor="#image of images">
                        <h2>{{image.title}}</h2>
                        <img src="{{image.url}}" alt="Cannot load image">
                    </li>
                </ul>
            </div>
        </css-carousel>
    </div>
`,
    directives: [CSSCarouselComponent],// PublicEventsComponent,
})
export class PublicEventsComponent {
    public message: string = "Public events packages include a password-protected online gallery with easy-to-share pictures. Licensing fees are contingent upon usage.";
    images: Images[] = [];
    constructor() {
        console.log("Lindsay's PublicEventsComponent loaded");
    }
}
