<?php
add_action( 'wp_enqueue_scripts', 'my_theme_enqueue_styles' );
function my_theme_enqueue_styles() {
    wp_enqueue_style( 'parent-style', get_template_directory_uri() . '/style.css' );

}

// Hide black admin bar at top of site preview ~ LB
add_filter( 'show_admin_bar', '__return_false' );


// Change content_width for twentyseventeen-child-dt from 960 to 1050 per https://make.wordpress.org/core/2016/11/29/theming-with-twenty-seventeen/ ~ LB 
function childtheme_content_width( $content_width ) {
    
        $content_width = 1050;
    
    return $content_width;
}
add_filter( 'twentyseventeen_content_width', 'childtheme_content_width' );

// ~ LB
add_image_size( 'wordpress-thumbnail', 200, 200, FALSE );

/*
	 * Enable support for Post Thumbnails on posts and pages.
	 *
	 * @link https://developer.wordpress.org/themes/functionality/featured-images-post-thumbnails/
	 */
	add_theme_support( 'post-thumbnails' );

	add_image_size( 'twentyseventeen-child-dt-featured-image', 2000, 1200, true );

?>
